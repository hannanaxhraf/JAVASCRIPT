
var count =0

function counter(){
count +=1
let saveEl= document.getElementById("save-el")


 document.getElementById("count-el").innerText=count;

}


counter();



function decremental(){

    if (count>0){

count -=1;

document.getElementById("count-el").innerText=count;



}
}
decremental();



function reset(){

    count=0

 document.getElementById("count-el").innerText=count

}

let welcomeEl= document.getElementById("welcome-el")

let name= "hannan"
let greetings= "welcome back to js "


welcomeEl.innerText= greetings + name;


welcomeEl.innerHTML= welcomeEl.innerHTML+"👋"




function save(){

    let countStr = count + " - " ;  

   let saveEl= document.getElementById("save-el")

    saveEl.innerText += countStr;

}



